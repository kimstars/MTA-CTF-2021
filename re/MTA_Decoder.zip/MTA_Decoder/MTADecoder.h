#pragma once

#ifndef DllExport
#define DllExport   __declspec( dllexport )
#endif // !1

DllExport void MTADecode(char* origText);